/**
 */
package configuratorProject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>my Enum</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see configuratorProject.ConfiguratorProjectPackage#getmyEnum()
 * @model abstract="true"
 * @generated
 */
public interface myEnum extends myValue {
} // myEnum
