/**
 */
package configuratorProject;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>my Expression</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see configuratorProject.ConfiguratorProjectPackage#getmyExpression()
 * @model abstract="true"
 * @generated
 */
public interface myExpression extends EObject {
} // myExpression
