/**
 */
package configuratorProject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>my Literal</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see configuratorProject.ConfiguratorProjectPackage#getmyLiteral()
 * @model abstract="true"
 * @generated
 */
public interface myLiteral extends myExpression {
} // myLiteral
