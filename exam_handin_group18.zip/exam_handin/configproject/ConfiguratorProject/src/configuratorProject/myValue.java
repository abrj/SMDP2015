/**
 */
package configuratorProject;


/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>my Value</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see configuratorProject.ConfiguratorProjectPackage#getmyValue()
 * @model abstract="true"
 * @generated
 */
public interface myValue extends myLiteral {
} // myValue
